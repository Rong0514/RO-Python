# -*- coding: utf-8 -*-
"""
Created on Tue Dec 12 17:37:18 2023

@author: willy
"""


from flask import Flask
from flask import render_template
from flask import request
from flask import make_response
import webbrowser

app = Flask(__name__)

@app.route('/login', methods = ['POST', 'GET'])
def login():
    if request.method == 'POST':
        name     = request.form.get("Name")
        username = request.form.get('Username')
        number   = request.form.get("Number")
        
        resp = make_response(render_template("home.html"))
        resp.set_cookie('nameID'     , name)
        resp.set_cookie('usernameID' , username)
        resp.set_cookie('numberID'   , number)
        return resp
    
    else:
        name     = request.cookies.get('nameID')
        username = request.cookies.get('usernameID')
        number   = request.cookies.get('numberID')
        return render_template("login.html", NAME = name , USERNAME = username , NUMBER = number)

@app.route('/successful')
def successful():
    name     = request.cookies.get('nameID')
    username = request.cookies.get('usernameID')
    number   = request.cookies.get('numberID')
    print(name , username , number)
    return '<h1>welcome,</h1>'+'<p>'+name+'</p>'+'<p>'+username+'</p>'+'<p>'+number+'</p>'

if __name__ == '__main__':
    webbrowser.open('http://127.0.0.1:5000/login')
    app.run(debug = False)
                       

