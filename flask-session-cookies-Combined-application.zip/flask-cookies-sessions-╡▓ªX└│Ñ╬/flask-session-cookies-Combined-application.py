# -*- coding: utf-8 -*-
"""
Created on Tue Dec 12 22:24:51 2023

@author: willy
"""

from flask import Flask
from flask import render_template
from flask import request
from flask import make_response
from flask import session
from flask import redirect
from flask import url_for
import webbrowser

app = Flask(__name__)

app.secret_key = 'Rong secret key'

@app.route("/home")
def home():
    if 'username' in session and 'password' in session and 'ID' in session and session["logined"]=="1":
        username = session['username']
        password = session['password']
        ID       = session['ID']
        return '登入使用者名稱是 :' + username + '<br>' +\
               '登入使用者密碼是 :' + password + '<br>' +\
               '登入使用者ID是  : ' + ID       +'<br>' +\
               "<b><a href = '/logout'>點選這裡登出</a></b>" 
    else:
        return "您尚未登入， <br><a href = '/login'></b>" + "點選這裡登入</b></a>"

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        session["username"] = request.form.get("username")
        session["password"] = request.form.get("password")
        session['ID']       = request.form.get("ID")
        session["logined"]  = "1"
        
        resp = make_response(render_template("home.html")) 
        resp.set_cookie('usernameID' , session["username"])
        resp.set_cookie('IDID'       , session['ID'])
        return resp
    else:
        return redirect("/login_form")
    
@app.route("/login_form" , methods=["GET", "POST"])
def login_form():
    if request.method == 'POST':
        Username = request.form.get('username')         
        IDS      = request.form.get("ID")                
        
        resp = make_response(render_template("home.html")) 
        resp.set_cookie('usernameID' , Username)      
        resp.set_cookie('IDID'   , IDS)             
        return resp
    else:
        Username = request.cookies.get('usernameID')   
        IDS      = request.cookies.get('IDID')     
        return render_template("login-form.html", USERNAME = Username , IDID = IDS) 

@app.route("/successful")
def successful():
    username = request.cookies.get('usernameID')      
    ID   = request.cookies.get('IDID')        
    print(username , ID)                  
    return '<h1>welcome,</h1>'+'<p>'+ username +'</p>'+'<p>'+ID+'</p>' +\
           "<b><a href = '/logout'>點選這裡登出</a></b>" 

@app.route("/logout")
def logout():
    session.pop('username'  , None)    
    session.pop('ID'        , None)
    return redirect(url_for('home'))  

if __name__ == "__main__":
    webbrowser.open('http://127.0.0.1:5000/home')
    app.run(debug=False)

